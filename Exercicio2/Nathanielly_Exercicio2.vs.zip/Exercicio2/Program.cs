﻿using System;

namespace Exercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Calculo Resultados = new Calculo();

            Resultados.Excercicio2();

        }
    }
}
