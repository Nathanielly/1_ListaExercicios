﻿using System;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
        
            Aula4 ResultadoFinal = new Aula4();
            

            ResultadoFinal.Exercicio4();
            
        }
    }
}
